var countdown                   = 100; //600
var currentCountdown            = countdown;
var countdownSliderStartHeight  = 999;
var plantPresentationTemplate   = null;
var fredselHasBeenInitialized   = false;
var response					= null;
var oldResponse					= null;
var animationInterval			= 50;
var barAnimationTime			= 2000;
var currentSlide				= null;
var hasBeenInitialized			= false;
var showWeather					= true;
var showClouds					= false;
var mapZoomLevel				= 5;
var customMapIcon				= "images/windpowerIcon.png";

function animateProgressBar(totalValue)
{
	if (currentSlide.find(".progressBarContainer").size() > 0)
	{		
		var currentValue 	= 0;
		var maxValue 		= response.maxPossibleProduction;
		var barWidth		= Math.round((totalValue / maxValue) * currentSlide.find(".progressBarContainer").width());
		$(".bar").css("width", barWidth + "px");
		setTimeout(function() {
			animateThisWillPower();
		}, 3000);
		
		var i = setInterval(function ()
	    {
	    	currentValue = Math.round(($(".progressBarContainer .bar").width() / barWidth) * totalValue);
			if (currentValue >= totalValue)        	
			{
				clearInterval(i);
				currentSlide.find(".progressBarContainer .value").text(totalValue);
			}
			else
			{
				currentSlide.find(".progressBarContainer .value").text(currentValue);
			}
	    }, 20);
	}
}

function animateThisWillPower()
{
	if (currentSlide.attr("id") == "totalPower")
	{
		$(".bubble").addClass("bubbleLarge");
		setTimeout(function () {
			$(".bubble div").fadeIn(1000);
		}, 1000);
	}
}

function setupMaps()
{
    //------------------------------------------------------------
    // Add the type as a prefix to the maps to create unique ids.
    //------------------------------------------------------------
    
    $(".map").each(function() {
        $(this).attr("id", $(this).closest(".slide").attr("id") + "_" + $(this).attr("id"));
    });
    
    $(".map").each(function() {
    	console.log("lat: " + parseFloat($(this).attr("data-lat")) + "long: " + parseFloat($(this).attr("data-long")));
        setupMap($(this).attr("id"), new google.maps.LatLng(parseFloat($(this).attr("data-lat")), parseFloat($(this).attr("data-long"))));
    });
}

function setupMap(aDivId, aLocation) 
{
    var mapOptions = {
        zoom: mapZoomLevel,
        center: aLocation,
        disableDefaultUI: true,
        mapTypeId: google.maps.MapTypeId.SATELLITE
    }
        
    var map = new google.maps.Map(document.getElementById(aDivId), mapOptions);
    
    if (showWeather)
    {
	  	var weatherLayer = new google.maps.weather.WeatherLayer({
	    	temperatureUnits: google.maps.weather.TemperatureUnit.CELSIUS,
	    	windSpeedUnit: google.maps.weather.WindSpeedUnit.METERS_PER_SECOND
	  	});
	 	weatherLayer.setMap(map);
    }

	if (showClouds)
	{
	  	var cloudLayer = new google.maps.weather.CloudLayer();
	  	cloudLayer.setMap(map);
	}
	
	if (customMapIcon != null)
	{
	    var marker = new google.maps.Marker({
	        position: aLocation,
	        map: map,
	        icon: customMapIcon
	    });
	}
	else
	{
		var marker = new google.maps.Marker({
	        position: aLocation,
	        map: map
	    });
	}
}

function setupCharts()
{
	if (currentSlide.attr("id") == "active")
	{
		currentSlide.find(".plantPresentation").each(function() {
	        setupChart($(this), "rgb(231, 209, 5)", "rgba(0, 0, 0, 0)");
	    });
	}
	else if (currentSlide.attr("id") == "availability")
	{
		currentSlide.find(".plantPresentation").each(function() {
	        setupChart($(this), "rgb(0, 181, 222)", "rgba(0, 0, 0, 0)");
	    });
	};
}

function setupChart(presentationObject, valueColor, fillerColor)
{
    var data = [
        {
            value: parseInt($(presentationObject).attr("data-value")),
            color: valueColor
        },
        {
            value: 100 - parseInt($(presentationObject).attr("data-value")),
            color : fillerColor
        }            
    ];
    
    var ctx = $(presentationObject).find(".chart").get(0).getContext("2d");
    var chartOptions = {segmentShowStroke : false, segmentStrokeColor : "#bbb", segmentStrokeWidth : 1, animation: true};
    var myNewChart = new Chart(ctx).Pie(data, chartOptions);
}

function setupFanSpeed()
{
    $(".windicon").each(function() {
        var dataValue = parseInt($(this).closest(".plantPresentation").attr("data-value"));
        var windSpeed = 4000 - ((4000 / 25) * dataValue) + 500;
        if (dataValue > 0)
        {
            $(this).css("animation-duration", windSpeed + "ms");
            $(this).css("-webkit-animation-duration", windSpeed + "ms");
        }
    });
    
}

function resetViews(aNewSlide)
{
	aNewSlide.find(".bar").width(1);
	aNewSlide.find(".plantPresentation").each(function() {
        if ($(this).closest(".slide").attr("id") != "windspeed")
        {
            var ctx = $(this).find(".chart").get(0).getContext("2d");
            ctx.clearRect(0, 0, 200, 200);
        }
    });
    aNewSlide.find(".bubble").removeClass("bubbleLarge");
    aNewSlide.find(".bubble div").hide();
}

function runAnimations()
{	
	//--------------------------------------------------------
	// Timer to make the animation wait a bit before starting
	//--------------------------------------------------------
	
	setTimeout(function() {
		setupCharts();
		animateProgressBar(response.totalPowerRightNow);
	}, 500);
}

function setupLabels()
{
	$("[data-label ^= label_]").each(function () {
		var label = $(this).attr("data-label");
		var labelText = response.labels[label];
		$(this).html(labelText);
	});
}

function displayTrend(newValue, oldValue, displayIn)
{
	var trend = "";
	
	if (newValue > oldValue)
	{
		trend = "&uarr;";
	}
	if (newValue < oldValue)
	{
		trend = "&darr;";
	}
	if (newValue === oldValue)
	{
		trend = "=";
	}
	$(displayIn).html(trend).fadeIn(500);
}

function refresh()
{
    currentCountdown = countdown;
        
    currentSlide = $("#slides .slide:first-child");
    
    resetViews(currentSlide);

    $("#countdown").fadeOut(1000);
	$("#latestUpdateContainer").fadeOut(1000, function() {
		$("#info").fadeIn(1000, function() {
			$.getJSON("jsonData.json", function(jsonResponse) {
		    	response = jsonResponse;

		    	if ($.fn.carouFredSel && !fredselHasBeenInitialized)
				{
					initializeFredsel();
					fredselHasBeenInitialized = true;
				}
				
				setupLabels();

		    	$("#maxPossibleProduction").text(response.maxPossibleProduction);
				
				plantPresentationTemplate.into($("#windspeed .contentBlock")).render(response.measurements.windspeed);
				plantPresentationTemplate.into($("#availability .contentBlock")).render(response.measurements.availability);
				plantPresentationTemplate.into($("#active .contentBlock")).render(response.measurements.capacity);
				
				$("#valueNo").text(response.marketValue.valueNo);
				$("#valueSe").text(response.marketValue.valueSe);
				$("#valueUkOffshore").text(response.marketValue.valueUkOffshore);
				$("#valueUkOnshore").text(response.marketValue.valueUkOnshore);
				
				$("#supplyValueNo").text(response.canSupply.no);
				$("#supplyValueSe").text(response.canSupply.se);
				$("#supplyValueUk").text(response.canSupply.uk);
				
				$("#totalProductionToday").text(response.totalProductionToday);
				$("#totalProductionYesterday").text(response.totalProductionYesterday);
				$("#totalProductionPreviousYear").text(response.totalProductionPreviousYear);
				
				setupMaps();
				setupFanSpeed();
				var updateTime = new Date();
				var paddingHours = "";
				if (updateTime.getHours() < 10)
				{
					paddingHours = "0";
				}
				var paddingMinutes = "";
				if (updateTime.getMinutes() < 10)
				{
					paddingMinutes = "0";
				}
				
				$("#info").fadeOut(1000, function() {
					$("#latestUpdate").text(paddingHours + updateTime.getHours() + ":" + paddingMinutes + updateTime.getMinutes());
					$("#latestUpdateContainer").fadeIn(1000);
					$("#countdown").fadeIn(1000);
			    	runAnimations();
				});
				
				if (oldResponse != null)
				{
					displayTrend(response.marketValue.nordpool, oldResponse.marketValue.nordpool, "#nordpoolTrend");
					displayTrend(response.marketValue.nasdaq, oldResponse.marketValue.nasdaq, "#nasdaqTrend");
				}
				
				oldResponse = response;
				
				if (!hasBeenInitialized)
				{
					$("#loadingLayer").hide();
					hasBeenInitialized = true;
				}
		    });
		});
	});
}

function refreshSmall()
{
	currentSlide = $("#slides");
	
	resetViews(currentSlide);
	
	$.getJSON("jsonData.json", function(jsonResponse) {
    	response = jsonResponse;
    	
    	setupLabels();
    	
    	$("#maximumProductionValue").text(response.maximumProduction);
    	
		plantPresentationTemplate.into($("#windspeed .dataContent")).render(response.measurements.windspeed);
		plantPresentationTemplate.into($("#capacity .dataContent")).render(response.measurements.capacity);
		plantPresentationTemplate.into($("#availability .dataContent")).render(response.measurements.availability);
		
		$("#nordpool").text(response.marketValue.nordpool);
		$("#nasdaq").text(response.marketValue.nasdaq);
		$(".marketValueRow .unit").text(response.labels.currency);
		
		if (oldResponse != null)
		{
			displayTrend(response.marketValue.nordpool, oldResponse.marketValue.nordpool, "#nordpoolTrend");
			displayTrend(response.marketValue.nasdaq, oldResponse.marketValue.nasdaq, "#nasdaqTrend");
		}
		
		oldResponse = response;
		
		setupMaps();
		setupFanSpeed();
	    runAnimations();
    });
}

function initializeFredsel()
{
    $(".slide").height($(window).height());
    $(".slide").width($(window).width());
    
    $("#slides").carouFredSel({
        items       	: {
        	visible		: 1,
        	height		: "100%"
        },
        width        	: "100%",
        height			: "100%",
        responsive    	: true,
        auto        	: false,
        /*
        auto : {
	        duration        : 2000,
	        timeoutDuration    : 10000,
	        pauseOnHover    : false
	    },
	    */
        prev         	: "#prev",
        next         	: "#next",
        scroll      	: {
        	onBefore 	: function(data) {
        		newSlide = $("#" + data.items.visible[0].id);
				resetViews(newSlide);
			},
			onAfter 	: function(data) {
				currentSlide = $("#" + data.items.visible[0].id);
				runAnimations();
			}
        },
        onCreate		: function() {
        	$(".caroufredsel_wrapper").height("100%");
        }
    });
}

$(".dataContent").bind("click", function () {
	resetViews(currentSlide);
	runAnimations();
});
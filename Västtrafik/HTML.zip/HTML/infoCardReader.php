<?php include 'head.inc'; ?>
<style>
	#infoCardReader ul li {
		width: 100%;
		display: block;
		margin-right:0.5em;
		margin-bottom:0.5em;
		overflow:hidden;
	}
	#infoCardReader ul li a {
		font-size: 0.8em;
		width: 100%;
		padding:0.8em;
	}
</style>
<section id="infoCardReader">
	<h1>Så här använder du kortläsaren</h1>
	<p>
		Kortläsare finns i olika färger (gul eller blå ombord och svart framme hos föraren). Har du ett periodkort håller du bara upp kortet framför kortläsaren ombord. Reser du med kontoladdning kan det hända att du måste trycka på kortläsarens knappar, till exempel när du reser mellan zoner. Här kan du läsa mer om hur du gör.
	</p>
	<ul>
		<li><a href="#ett" class="button">1. Resa med periodkort</a></li>
		<li><a href="#tva" class="button">2. Resa inom en zon</a></li>
		<li><a href="#tre" class="button">3. Resa mellan eller genom zoner</a></li>
		<li><a href="#fyra" class="button">4. Osäker på om du passerar en zongräns?</a></li>
		<li><a href="#fem" class="button">5. Betala en del av resan med periodkort</a></li>
		<li><a href="#sex" class="button">6. Resa flera personer på samma kort inom en zon</a></li>
		<li><a href="#sju" class="button">7. Resa flera personer på samma kort mellan zoner</a></li>
		<li><a href="#atta" class="button">8. Förändring av kortprofiler</a></li>
		<li><a href="#nio" class="button">9. Glömt bort att checka ut vid flerzonsresa?</a></li>
		<li><a href="#tio" class="button">10. Kolla ditt saldo</a></li>
	</ul>
</section>
<section id="cardStory">
	<ul>
		<li class="arrow_box"><a id="ett"></a>
			<h4>1. Resa med periodkort</h4>
			<p>
				Uppe i högra hörnet finns en orange manick. Det är Reseplaneraren. Fyll i var du är, vart du ska och när du vill åka, så tar Reseplaneraren fram den perfekta rutten.			
			</p>
			<img class="center" src="http://lorempixel.com/100/75/nature" alt="bild1"/>
		</li>
		<li class="clearfix"><a href="#" class="right backToTop">&#8673; Upp</a></li>
		<li class="arrow_box"><a id="tva"></a>
			<h4>2. Resa med periodkort</h4>
			<p>
				Uppe i högra hörnet finns en orange manick. Det är Reseplaneraren. Fyll i var du är, vart du ska och när du vill åka, så tar Reseplaneraren fram den perfekta rutten.
			</p>
			<img class="center" src="http://lorempixel.com/100/75/nature" alt="bild2"/>
		</li>
		<li class="clearfix"><a href="#top" class="right backToTop">&#8673; Upp</a></li>
		<li class="arrow_box"><a id="tre"></a>
			<h4>3. Resa med periodkort</h4>
			<p>
				Uppe i högra hörnet finns en orange manick. Det är Reseplaneraren. Fyll i var du är, vart du ska och när du vill åka, så tar Reseplaneraren fram den perfekta rutten.
			</p>
			<img class="center" src="http://lorempixel.com/100/75/nature" alt="bild2"/>
		</li>
		<li class="clearfix"><a href="#top" class="right backToTop">&#8673; Upp</a></li>
		<li class="arrow_box"><a id="fyra"></a>
			<h4>4. Resa med periodkort</h4>
			<p>
				Uppe i högra hörnet finns en orange manick. Det är Reseplaneraren. Fyll i var du är, vart du ska och när du vill åka, så tar Reseplaneraren fram den perfekta rutten.
			</p>
			<img class="center" src="http://lorempixel.com/100/75/nature" alt="bild2"/>
		</li>
		<li class="clearfix"><a href="#top" class="right backToTop">&#8673; Upp</a></li>
		<li class="arrow_box"><a id="fem"></a>
			<h4>5. Resa med periodkort</h4>
			<p>
				Uppe i högra hörnet finns en orange manick. Det är Reseplaneraren. Fyll i var du är, vart du ska och när du vill åka, så tar Reseplaneraren fram den perfekta rutten.
			</p>
			<img class="center" src="http://lorempixel.com/100/75/nature" alt="bild2"/>
		</li>
		<li class="clearfix"><a href="#top" class="right backToTop">&#8673; Upp</a></li>
		<li class="arrow_box"><a id="sex"></a>
			<h4>6. Resa med periodkort</h4>
			<p>
				Uppe i högra hörnet finns en orange manick. Det är Reseplaneraren. Fyll i var du är, vart du ska och när du vill åka, så tar Reseplaneraren fram den perfekta rutten.
			</p>
			<img class="center" src="http://lorempixel.com/100/75/nature" alt="bild2"/>
		</li>
		<li class="clearfix"><a href="#top" class="right backToTop">&#8673; Upp</a></li>
		<li class="arrow_box"><a id="sju"></a>
			<h4>7. Resa med periodkort</h4>
			<p>
				Uppe i högra hörnet finns en orange manick. Det är Reseplaneraren. Fyll i var du är, vart du ska och när du vill åka, så tar Reseplaneraren fram den perfekta rutten.
			</p>
			<img class="center" src="http://lorempixel.com/100/75/nature" alt="bild2"/>
		</li>
		<li class="clearfix"><a href="#top" class="right backToTop">&#8673; Upp</a></li>
		<li class="arrow_box"><a id="atta"></a>
			<h4>8. Resa med periodkort</h4>
			<p>
				Uppe i högra hörnet finns en orange manick. Det är Reseplaneraren. Fyll i var du är, vart du ska och när du vill åka, så tar Reseplaneraren fram den perfekta rutten.
			</p>
			<img class="center" src="http://lorempixel.com/100/75/nature" alt="bild2"/>
		</li>
		<li class="clearfix"><a href="#top" class="right backToTop">&#8673; Upp</a></li>
		<li class="arrow_box"><a id="nio"></a>
			<h4>9. Resa med periodkort</h4>
			<p>
				Uppe i högra hörnet finns en orange manick. Det är Reseplaneraren. Fyll i var du är, vart du ska och när du vill åka, så tar Reseplaneraren fram den perfekta rutten.
			</p>
			<img class="center" src="http://lorempixel.com/100/75/nature" alt="bild2"/>
		</li>
		<li class="clearfix"><a href="#top" class="right backToTop">&#8673; Upp</a></li>
		<li class="arrow_box"><a id="tio"></a>
			<h4>10. Resa med periodkort</h4>
			<p>
				Uppe i högra hörnet finns en orange manick. Det är Reseplaneraren. Fyll i var du är, vart du ska och när du vill åka, så tar Reseplaneraren fram den perfekta rutten.
			</p>
			<img class="center" src="http://lorempixel.com/100/75/nature" alt="bild2"/>
		</li>
		<li class="clearfix"><a href="#top" class="right backToTop">&#8673; Upp</a></li>
	</ul>
</section>
<?php include 'foot.inc'; ?>
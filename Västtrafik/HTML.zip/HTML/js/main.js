var currentPosition = null;

$(document).ready(function() {
	
	if (retrieveValue("vt-topalert-12345") != "closed")
	{
		$(".topAlert").show();
	}
	
	$("#menuHeader a").click(function(event) {
		$("#loggedOutHeader").toggle();
	});
	
	/*---------------
	  Expandable menu
	  ---------------*/

	$(".expand").click(function(event) {
		event.preventDefault();
		/* CLOSE OTHERS BEFORE OPENING
		if ($(event.target).closest("li").hasClass("active"))
		{
			$(event.target).closest("li").children("ul").slideUp(200);
			$(event.target).closest("li").removeClass("active");
		}
		else
		{
			$("ul#menuTree").find("li.active").find("ul").slideUp(100);
			$("ul#menuTree").find("li.active").removeClass("active");
			$(event.target).closest("li").children("ul").slideDown(200);
			$(event.target).closest("li").addClass("active");
		}
		*/
		$(event.target).closest("li").toggleClass("active");
		$(event.target).closest("li").children("ul").slideToggle(200);
	});

	$("#menu").click(function() {
		$("#searchForm").hide().removeClass("expanded");
		$("#vt-menu").show();
		toggleMenu();
	});
	
	$(".magglas").click(function() {
		toggleSearch();
	});
	
	/*-------------------
	     Search field
	  -------------------*/
	
	$("#searchButton").click(function () {
		$(this).closest("form").submit();
	});
		
	$(".searchBox").keyup(function() {
		if ($(this).val() == "")
		{
			$("#clearButton").hide();
		}
		else
		{
			$("#clearButton").show();
		}
			
	});
	
	$("#clearButton").click(function() {
		var textField = $(this).closest("form").find("input[type='text']");
		textField.val("");
		textField.focus();
		$("#clearButton").hide();
	});
	
	/*----------------
	  TRIP FINDER
	  ----------------*/
	  
	$(".tripFinderSelector").click(function() {
		if($(this).hasClass("selected"))
		{
			$(this).removeClass("selected");
			$("#tripFinderDrawer").slideUp(200);
		}
		else
		{
			$(".tripFinderSelector").removeClass("selected");
			$(this).addClass("selected");
			$("#tripFinderDrawer").slideDown(200);
			var selectedFinder = $(this).attr("id");
			$(".tripFinderInnerDrawer").hide();
			$("#tripFinderInnerDrawer-" + selectedFinder).show();
		}
	});
	  
	/*----------------
	    MISC BUTTONS
	  ----------------*/
	
	$(".topAlert .icon").click(function () {
		$(".topAlert").slideUp(200);
		storeValue("vt-topalert-12345", "closed")
	});
	
	$("#backToTop").click(function () {
		$('body,html').animate({
		  scrollTop: 0
		}, 200);
	});
	$(".backToTop").click(function (event) {
		event.preventDefault();
		$('body,html').animate({
		  scrollTop: 0
		}, 200);
	});
	$('a[href*=#]:not([href=#])').click(function() {
	    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') || location.hostname == this.hostname) {
	    	console.log("bo");
	        var target = $(this.hash);
	        target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
	           if (target.length) {
	             $('html,body').animate({
	                 scrollTop: target.offset().top-50
	            }, 250);
	            return false;
	        }
	    }
	});
	if (isMobile.iOS())
	{		
		$("#searchField").focus(function() {
			$(window).scrollTop(0);
			
			$("#mainMenu").css("position", "absolute");
			$("#mainMenu").css("top", "0");
			$("#searchForm").css("position", "absolute");
			$("#searchForm").css("top", "45px");
		});
		
		$("#searchField").blur(function() {
			$("#mainMenu").css("position", "fixed");
			$("#mainMenu").css("top", "0");
			$("#searchForm").css("position", "fixed");
			$("#searchForm").css("top", "45px");
		});
	}
	
	/*----------------------------------
	  Swipe event for the main container
	  ----------------------------------*/
	/*
	$("#vt-container").swipe({
		excludedElements:".cardRoller",
		click: function (event, target) {
			//$(target).trigger("click");
		},
		swipeRight:function(event, direction, distance, duration, fingerCount) {
			showMenu();
			$("#searchForm").hide().removeClass("expanded");
		},
		swipeLeft:function(event, direction, distance, duration, fingerCount) {
			hideMenu();
		}
	});
	*/
	
	/*----------------------------------
	  Events for the overlay
	  ----------------------------------*/

	$("#vt-overlay").click(function () {
		hideMenu();
		hideSearch();
	});
	
	$("#vt-pusher").click(function () {
		hideMenu();
	});
	
	setTimeout(function() {setupCaroufredsel("#newsfeed")}, 10); // Delay to avoid a bug when initializing several carousels at the same time.
	setTimeout(function() {setupCaroufredsel("#trafficSituations")}, 20); // Delay to avoid a bug when initializing several carousels at the same time.
});

function setupCaroufredsel(container)
{
	if ($(container + " .cardRoller").size() > 0)
	{
		$(container + " .cardRoller").carouFredSel({
		    circular 		: true,
			infinite		: false,
			swipe        	: {
		        onTouch     : true,
		        onMouse     : true
			},
			items 			: {
				visible 	: 1
			},
			responsive  	: true,
			direction 		: "left",
			scroll : {
				items 		: 1,
				easing 		: "swing",
				duration 	: 200,
			},
			pagination		: {
				container	: container + " .cardSwiperPagination",
				keys        : false
			},
			auto : {
				play		: false
			}
		});

		$(container + " .cardRoller").swipe({
			click: function (event, target) {
				document.location.href = $(target).closest("li").attr("data-target");
			}
		});
	}
}

$(window).resize(function() 
{ 
	$("#newsfeed .cardRoller").trigger("destroy");
	$("#trafficSituations .cardRoller").trigger("destroy"); 
	
	setupCaroufredsel("#newsfeed");
	setupCaroufredsel("#trafficSituations");

}); 

function showMenu()
{
	$("#vt-container").addClass("openMenu").removeClass("closeMenu");
	$("#mainMenu").appendTo("#vt-pusher");
	$("#vt-overlay").show();
}

function hideMenu()
{
	$("#vt-container").removeClass("openMenu").addClass("closeMenu");
	setTimeout(function() {
		$("#mainMenu").appendTo("#vt-container");
		$("#vt-menu").hide();
	}, 200);
	$("#vt-overlay").hide();
}

function toggleMenu()
{
	if ($("#vt-container").hasClass("openMenu"))
	{
		hideMenu();
	}
	else
	{
		showMenu();
	}
}

function showSearch() {
	$("#vt-overlay").show();
	$("#searchForm").show().animate({top: "45"}, function() {$(this).addClass("expanded")});
	$("#searchField").focus();
}

function hideSearch() {
	if (isMobile.iOS())
	{
		$("#mainMenu").css("position", "fixed");
		$("#mainMenu").css("top", "0");
		$("#searchForm").blur();
		$("#searchForm").css("position", "fixed");
		$("#searchForm").css("top", "-200px");
	}
	$("#searchForm").animate({top: "-200"}, function() {
		$(this).hide(); 
		$(this).removeClass("expanded");
		$("#vt-overlay").hide();
	});
}

function toggleSearch()
{
	if ($("#searchForm").hasClass("expanded"))
	{
		hideSearch();
	}
	else
	{
		showSearch();		
	}
}

function getPosition()
{
	$("#location").html("Var god vänta. Position hämtas...");
	if (navigator.geolocation)
	{
		position = navigator.geolocation.getCurrentPosition(function(position) {
			currentPosition = position;
			showPosition();
		}, showError);
	}
	else
	{
		alert("Din webbläsare stöder inte GPS-position.");
	}
}

function showPosition()
{
	if (currentPosition != null)
	{
		$("#location").html(currentPosition.coords.latitude + ", " + currentPosition.coords.longitude);
	}
	else
	{
		alert("Du måste hämta positionen först.");
	}
}

function showError(error)
{
	switch(error.code) 
	{
		case error.PERMISSION_DENIED:
			alert("User denied the request for Geolocation.")
		break;
		case error.POSITION_UNAVAILABLE:
			alert("Location information is unavailable.")
		break;
		case error.TIMEOUT:
			alert("The request to get user location timed out.")
		break;
		case error.UNKNOWN_ERROR:
			alert("An unknown error occurred.")
		break;
	}
}

var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function() {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i);
    },
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};

function storeValue (name, value)
{
	if (Modernizr.localstorage) 
	{
		localStorage.setItem(name, value);
	} 
	else 
	{
		setCookie(name, value, 7);
	}
}

function retrieveValue (name)
{
	if (Modernizr.localstorage) 
	{
		return localStorage.getItem(name);
	} 
	else 
	{
		return getCookie(name);
	}
}

function setCookie(name, value, days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
		var expires = "; expires=" + date.toGMTString();
	} else {
		var expires = "";
	}
	document.cookie = name + "=" + value + expires + "; path=/";
}

function getCookie(name) {
	var fQName = name + "=";
	var cString = document.cookie.split(';');
	for (var i=0;i<cString.length;i++) {
		var c = cString[i];
		while (c.charAt(0) == ' '){c = c.substring(1, c.length);}
		if (c.indexOf(fQName) == 0){
			return c.substring(fQName.length, c.length);
		}
	}
	return null;
}
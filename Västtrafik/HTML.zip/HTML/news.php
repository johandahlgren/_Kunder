<?php include 'head.inc'; ?>	
<section>
	<div class="newsItem">
		<a href="newsDetail.php">
			<h2>Lorem ipsum dolor sit amet</h2>
			<p>
				<img src="http://lorempixel.com/200/100/nature" />
				Turpis vel ullamcorper volutpat arcu lorem? Velit etiam risus egestas rhoncus tincidunt; Nisi adipiscing sagittis vehicula bibendum sagittis ligula dui dolor tincidunt? </p>
		</a>
	</div>
	
	<div class="newsItem">
		<a href="newsDetail.php">
			<h2>Interdum aliquam libero risus</h2>
			<p>
				In iaculis varius eu dignissim nibh luctus interdum aliquam libero risus erat; Erat integer sit sed nec at aenean imperdiet non! A turpis volutpat penatibus risus etiam suscipit; Vitae donec arcu eget phasellus ut.
			</p>
		</a>
	</div>
	
	<div class="newsItem">
		<a href="newsDetail.php">
			<h2>Urna nibh sed enim ultricies nisl</h2>
			<p>
				<img src="http://lorempixel.com/200/100/nature" />
				 Varius dui porta turpis felis ligula consectetur. Urna nibh sed enim ultricies nisl, Ut quis lectus nunc varius etiam fermentum at elit ut consequat sed! Posuere accumsan porta donec lacus aliquet libero at convallis.
			</p>
		</a>
	</div>
	
	<div class="newsItem">
		<a href="newsDetail.php">
			<h2>Suspendisse amet nibh blandit aliquam tristique ut pellentesque</h2>
			<p>
				<img src="http://lorempixel.com/200/100/nature" />
				Nisl a blandit nam a ut consectetur arcu venenatis, Erat massa tristique nec tincidunt: Suspendisse amet nibh blandit aliquam tristique ut pellentesque tincidunt. Turpis turpis eu in cras lacus cursus sit erat a.
			</p>
		</a>
	</div>
	<hr/>
	<a href="javascript:history.go(-1);">&laquo; Tillbaka</a>
</section>

<?php include 'foot.inc'; ?>
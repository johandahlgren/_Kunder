<?php include 'head.inc'; ?>
<section id="myCards">
	<p>
		Det eller de kort som du har registrerat hos Västtrafik syns här. Du får snabbt koll på saldo och giltighetstid. Du kan även spärra dina kort.
	</p>
	<ul>
		<li>
			<div style="float:left;width:55%;margin-right:5%;height:6em;border:1px dashed deeppink;">
				<small>placeholder</small>
			</div>
			<div style="float:right:width:40%;" class="clearfix">
				<p>
					Johns Månadskort
					<button>Spärra kortet</button>
				</p>
			</div>
			<table>
				<tr>
					<th>Kortnummer:</th>
					<td>240111842240076</td>
				</tr>
				<tr>
					<th>Kortets utgångsdatum:</th>
					<td>2016-06-19</td>
				</tr>
				<tr>
					<th>Kontoladdning:</th>
					<td>-11 kr</td>
				</tr>
				<tr>
					<th>Profil:</th>
					<td>Vuxen</td>
				</tr>
				<tr>
					<td colspan="2"><strong>Saldot uppdaterades:</strong> 2011-08-26 15:20</td>
				</tr>
				<tr>
					<th>Period:</th>
					<td>Kommun Göteborg Vuxen Giltigt t.o.m. 2013-09-10</td>
				</tr>
			</table>
		</li>
		<li>repeat</li>
	</ul>
	<hr/>
	<p>
		<em>Information om att detta inte är hela mina sidor - att övriga funktioner endast fungerar på desktopversion</em>
	</p>
	<p>
		<em>
		Maecenas faucibus mollis interdum. Donec id elit non mi porta gravida at eget metus. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Curabitur blandit tempus porttitor.
		</em>
	</p>
</section>

<?php include 'foot.inc'; ?>
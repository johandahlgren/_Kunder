<?php include 'head.inc'; ?>
<style>
	form.fullWidth input[type="text"],
	form.fullWidth input[type="email"],
	form.fullWidth input[type="password"] {
		border-color: rgba(0,0,0,0.4);
	}
	form.fullWidth input:focus:required:invalid,
	form.fullWidth input:focus:invalid {
			border-color: rgba(255,0,0,0.9);
	}
	form.fullWidth input:focus:required:valid {
		border-color: rgba(0,255,0,0.9);
	}
	form.fullWidth input:required:valid {
		background: white url("img/greendot.svg") right 10px center no-repeat;
		background-size: 1em 1em;
	}

</style>
<section>
	<h1>Glömt Användarnamn</h1>
	<p class="ingress">Har du glömt ditt användarnamn?</p>
	<p>
	Fyll i ditt förnamn. Skriv sedan in den e-postadress du angav vid registreringen.
	Klicka på "Skicka" så kommer ett e-postbrev med ditt användarnamn att skickas till dig (under förutsättning att ditt förnamn och e-postadress är korrekta). Har du inte angett någon e-postadress kan du kontakta vår kundservice på tel <a href="tel:+46771414300">0771-41 43 00</a>, så skickar de nya uppgifter till dig via post. Om du får ett felmeddelande beror det troligen på att du bytt e-postadress. Kontakta då vår kundservice för att få hjälp.</p>
	<form id="lostUserid" class="fullWidth">
		<label for="name">Förnamn</label>
		<input type="text" id="name" name="name" placeholder="Skriv in förnamn" required spellcheck="false" autocomplete="off" autocapitalize="on"/>
		<label for="epost">E-post</label>
		<input type="email" id="epost" name="epost" placeholder="Skriv in e-postadress" required/>
		<input type="submit" name="send" value="Skicka" id="skicka" class="nButton" />
	</form>
</section>

<?php include 'foot.inc'; ?>
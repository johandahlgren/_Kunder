<?php include 'head.inc'; ?>

<h1>Sökresultat</h1>
<p>
	Hepp!
</p>
					
<?php include 'foot.inc'; ?>
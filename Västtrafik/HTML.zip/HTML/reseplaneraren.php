<?php include 'head.inc'; ?>
<section>
	<h2>Reseplaneraren</h2>
	<a href="javascript: getPosition();">Hämta GPS-position</a><br/>
	<div id="location" style="margin: 20px 0; color: rgb(200, 200, 200);">Position saknas.</div>
</section>
<?php include 'foot.inc'; ?>
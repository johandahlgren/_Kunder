<?php include 'head.inc'; ?>
<style>
	form.fullWidth input[type="text"],
	form.fullWidth input[type="email"],
	form.fullWidth input[type="password"] {
		border-color: rgba(0,0,0,0.4);
		border-radius:0.5em;
	}
	form.fullWidth input:focus:required:invalid,
	form.fullWidth input:focus:invalid {
			border-color: rgba(255,0,0,0.9);
	}
	form.fullWidth input:focus:required:valid {
		border-color: rgba(0,255,0,0.9);
	}
	.formHint, .formError {
		display: none;
	}
	.formHint p,
	.formError p {padding:0.3em;}
	form.fullWidth input:focus:required + span.formHint  {
		display: block;
		width: 100%;
		background-color:rgba(0,0,0,0.1);
		box-shadow: inset 0px 1px 3px rgba(0,0,0,0.1);
		margin-top:-1em;
	}
	form.fullWidth input:required:invalid ~ span.formError  {
		display: block;
		width: 100%;
		background-color:rgba(255,0,0,0.1);
		box-shadow: inset 0px 1px 3px rgba(255,0,0,0.2);
		margin-top:-1em;
	}
	form.fullWidth input[value=""][type="email"]:required:invalid + span.formError,
	form.fullWidth input[value=""][type="text"]:required:invalid + span.formError{
		display: none;
	}
	form.fullWidth input:required:valid {
		background: white url("img/greendot.svg") right 10px center no-repeat;
		background-size: 1em 1em;
	}

</style>
<section>
	<h1>Glömt Lösenord</h1>
	<p class="ingress">
		Har du glömt ditt lösenord
	</p>
	<p>
		Ange användarnamn och den e-postadress som du har registrerat på Mina Sidor så skickar vi en länk för lösenordsåterställning till din e-post.
	</p>
	<p>
		Om du är osäker på ditt användarnamn, så klicka här:<br/><a href="minaSidor-glomtanvid.php">Glömt användarnamn</a>.
	</p>
	<form id="lostUserid" class="fullWidth">
		<label for="name">E-post</label>
		<input type="email" id="epost" name="epost" value="" placeholder="Skriv in e-postadress" required spellcheck="false" autocomplete="off"/>
		<span class="formHint"><p>Giltigt format "namn@exempel.se"</p></span>
		<span class="formError"><p>Felaktig e-postadress</p></span>
		<label for="epost">Användarnamn</label>
		<input type="text" id="name" name="name" value="" placeholder="Skriv in användarnamn" required  spellcheck="false" autocomplete="off"/>
		<span class="formError"><p>Användarnamn måste anges</p></span>	
		<input type="submit" name="send" value="skicka" id="skicka" class="nButton"/>
	</form>
</section>

<?php include 'foot.inc'; ?>
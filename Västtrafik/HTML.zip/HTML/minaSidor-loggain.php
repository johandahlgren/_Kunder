<?php include 'head.inc'; ?>


<?php include 'foot.inc'; ?>
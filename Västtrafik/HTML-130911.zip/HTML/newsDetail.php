<?php include 'head.inc'; ?>
<section class="newsDetail">
	<h1>Detta är en bra nyhet</h1>
	<p class="ingress">
	Jujubes icing jelly-o icing gingerbread tootsie roll pudding toffee fruitcake. Danish pie jujubes sesame snaps.
	</p>
	<img src="http://lorempixel.com/200/100/nature" />
	<p>
		Chocolate bar gummi <strong>bears</strong> cupcake. <em>Caramels</em> jelly <a href="#">bonbon</a> caramels candy chupa chups danish biscuit dragée. Jelly-o jelly-o wafer bonbon marzipan icing bonbon cupcake sesame snaps. Apple pie chocolate bar dragée. Tart unerdwear.com topping chocolate cake chupa chups cake. Macaroon marshmallow lollipop toffee pastry soufflé. Jujubes icing jelly-o icing gingerbread tootsie roll pudding toffee fruitcake. Danish pie jujubes sesame snaps. Wafer cotton candy marzipan wafer ice cream jujubes tootsie roll <a href="#" title="tootsie roll länk">tootsie roll</a>. Jujubes macaroon applicake sugar plum oat cake candy canes powder chocolate cake. Marshmallow cotton candy macaroon tart sesame snaps caramels muffin. Toffee candy canes candy canes chocolate chocolate cake. Dessert icing soufflé chocolate bar.
	</p>
	<p>
	<em>Applicake</em> oat cake tootsie roll ice cream halvah chocolate cake candy. Jujubes cookie pie ice cream chocolate cake sweet roll sweet roll soufflé toffee. Fruitcake applicake brownie cotton candy wafer ice cream cotton candy. Tart lollipop jelly-o. Soufflé pie biscuit marshmallow lemon drops. Danish cupcake sweet ice cream lemon drops wafer sweet roll. Liquorice tootsie roll tootsie roll soufflé. Soufflé gingerbread pie wafer. Chocolate bar tart donut candy canes. Marzipan bear claw candy canes tiramisu jelly tart danish applicake wafer. Bear claw marzipan cheesecake chocolate bar donut lollipop. Sugar plum sugar plum ice cream bonbon unerdwear.com sesame snaps. Dessert croissant pie liquorice toffee pudding cupcake. Macaroon croissant muffin toffee apple pie icing topping candy.
	</p>
	<hr/>
	<a href="javascript:history.go(-1);">&laquo; Tillbaka</a>
</section>
<?php include 'foot.inc'; ?>